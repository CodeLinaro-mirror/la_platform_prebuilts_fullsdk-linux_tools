<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1504242040463'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/usr/local/google/buildbot/src/googleplex-android/studio-sdk-release/out/host/maven/bundles-25.2.2-SNAPSHOT/products/monitorproduct/linux/gtk/x86_64/monitor'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/usr/local/google/buildbot/src/googleplex-android/studio-sdk-release/out/host/maven/bundles-25.2.2-SNAPSHOT/products/monitorproduct/linux/gtk/x86_64/monitor'/>
  </properties>
</profile>
